# JavaScript REST client and utils for Clever Cloud's API

> 🚧 **New Client Documentation Available**: For the new command-pattern client (beta), see [NEW_CLIENT.md](NEW_CLIENT.md)

## What is this?

This project contains a REST client for Clever Cloud's API and some utils.

## How do I use this?

First, you need to install the Node.js module:

```sh
pnpm install @clevercloud/client
```

We recommend using [mise](https://mise.jdx.dev/) to make sure you rely on the same Node.js & pnpm versions as us (defined in [`mise.toml`](mise.toml)).

All API REST paths are accessible as "functions" organized in "services".
A call to a function of a service will just prepare the HTTP request and return the request params in an object via a promise.
It won't authenticate the request and it won't send it.

You will need to chain some helpers to the function call to:

* Specify the API host (prod, preprod...)
* Add the right authentication headers (oAuth v1 or other...)
* Send the HTTP request with your favourite lib/code
* Handle the response with your favourite lib/code

Those helpers are ready to use for browsers or Node.js and for oAuth v1 signature auth.
The recommended way is to wrap those helpers in one place of your app and to reuse it everywhere you need to send API calls.

Here's an example using ECMAScript modules with oAuth v1 signature and using the `fetch` API to send requests.

In a file, expose this function:

```js
import { addOauthHeader } from '@clevercloud/client/esm/oauth.js';
import { prefixUrl } from '@clevercloud/client/esm/prefix-url.js';
import { request } from '@clevercloud/client/esm/request.fetch.js';

export function sendToApi (requestParams) {

  // load and cache config and tokens
  const API_HOST = 'https://api.clever-cloud.com'
  const tokens = {
    OAUTH_CONSUMER_KEY: 'your OAUTH_CONSUMER_KEY',
    OAUTH_CONSUMER_SECRET: 'your OAUTH_CONSUMER_SECRET',
    API_OAUTH_TOKEN: 'your API_OAUTH_TOKEN',
    API_OAUTH_TOKEN_SECRET: 'your API_OAUTH_TOKEN_SECRET',
  }

  return Promise.resolve(requestParams)
    .then(prefixUrl(API_HOST))
    .then(addOauthHeader(tokens))
    .then(request);
    // chain a .catch() call here if you need to handle some errors or maybe redirect to login
}
```

NOTE: If your project relies on a specific REST library (axios, jQuery...), you'll have to write your own request function to plug the params to your lib instead of using `request.fetch.js`.

Then, in any file of your app, import the API function you need directly (it helps with tree shaking), call it and add a `.then(sendToApi)` like this:

```js
import { getAllEnvVars } from '@clevercloud/client/esm/api/v2/application.js';
import { sendToApi } from '../send-to-api.js';

const envVars = await getAllEnvVars({ id: oid, appId }).then(sendToApi);
```

NOTE: It returns a promise, you may want to use `await` with it.

## How can I get the oAuth configuration?

A general documentation is proposed on [our Website](https://www.clever.cloud/developers/api/howto#oauth1).
As stated in the documentation:

> You need to create an oAuth consumer token in the Clever Cloud console. Click on "Create...", then on "an oauth consumer" under your organization name. All created consumers will appear under the list of applications and add-ons.

Once you got the consumer, you still need to generate the aAuth tokens. You may do the whole aAuth dance in the browser.

If you use the [clever-tools](https://github.com/CleverCloud/clever-tools) CLI, you can also generate tokens using the following command :

```sh
clever login
```

Once successfully logged in, you’ll be provided with a token / secret couple.

## Logs stream and event API stream (v2)

### Retrieving logs from Clever Cloud

This stream is exposed the inner SSE source with [`component-emitter`](https://www.npmjs.com/package/component-emitter), a tiny lib implementing an API that closely match both [`EventTarget`](https://developer.mozilla.org/en-US/docs/Web/API/EventTarget) from the DOM and [`EventEmitter`](https://nodejs.org/api/events.html) from Node.js.

Here's an example of how to use `LogsStream` to retrieve live logs from an app:

```js
// Browser implementation or Node.js implementation
import { LogsStream } from '@clevercloud/client/esm/streams/logs.browser.js';
// import { LogsStream } from '@clevercloud/client/esm/streams/logs.node.js';

// Load and cache config and tokens
const API_HOST = 'https://api.clever-cloud.com';
const tokens = {
  OAUTH_CONSUMER_KEY: 'your OAUTH_CONSUMER_KEY',
  OAUTH_CONSUMER_SECRET: 'your OAUTH_CONSUMER_SECRET',
  API_OAUTH_TOKEN: 'your API_OAUTH_TOKEN',
  API_OAUTH_TOKEN_SECRET: 'your API_OAUTH_TOKEN_SECRET',
};

// Create a LogsStream instance (filter and deploymentId are optional)
const logsStream = new LogsStream({ apiHost: API_HOST, tokens, appId, filter, deploymentId });

// Listen to "log" events
logsStream.on('log', (rawLogLine) => console.log(rawLogLine));

// Open the stream
logsStream.open();
```

### Retrieving events from Clever Cloud

This stream is exposed the inner WebSocket source with [`component-emitter`](https://www.npmjs.com/package/component-emitter), a tiny lib implementing an API that closely match both [`EventTarget`](https://developer.mozilla.org/en-US/docs/Web/API/EventTarget) from the DOM and [`EventEmitter`](https://nodejs.org/api/events.html) from Node.js.

Here's an example of how to use `EventsStream` to retrieve events from the Clever Cloud platform:

```js
// Browser and Node.js 21+ implementation
import { EventsStream } from '@clevercloud/client/esm/streams/events.js';

// Load and cache config and tokens
const API_HOST = 'https://api.clever-cloud.com';
const tokens = {
  OAUTH_CONSUMER_KEY: 'your OAUTH_CONSUMER_KEY',
  OAUTH_CONSUMER_SECRET: 'your OAUTH_CONSUMER_SECRET',
  API_OAUTH_TOKEN: 'your API_OAUTH_TOKEN',
  API_OAUTH_TOKEN_SECRET: 'your API_OAUTH_TOKEN_SECRET',
};

// Create an EventsStream instance (appId is optional)
const eventsStream = new EventsStream({ apiHost: API_HOST, tokens, appId });

// Listen to "event" events
eventsStream.on('event', (rawEvent) => console.log(rawEvent));

// Open the stream
eventsStream.open();
```

### Handling errors

When an error (network failures, bad authentication...) occurs with the source stream, an error event is emitted:

```js
stream.on('error', (error) => console.error(error));
```

* By default, when a network failure is detected, an error is emitted and the stream is closed automatically.
* If you enable the auto retry behaviour, when a network failure is detected, it won't emit an error.
* If you enable the auto retry behaviour AND set a max number of retries, it will emit an error.

See "auto retry behaviour" section for more details...

### Close the stream

You can close the stream at any time like this:

```js
stream.close();
```

It won't remove event listeners from the stream instance so you can re-open it easily.

### Auto retry behaviour

When you call `.open()` on a stream, it's not resilient to network failures by default.
We have an opt-in auto retry behaviour to handle those, you can enable it when you open the stream like this:

```js
stream.open({ autoRetry: true });
```

Network failure are detected with a ping/pong system.
When such a failure is detected and auto retry behaviour is enabled, the source stream is closed and a new open is attempted automatically.

You probably don't need to but you can listen to events related to this auto retry behaviour:

```js
// "close" event is emitted each time a network failure is detected (or any unknown error not related to authentication)
stream.on('close', (reason) => console.log('Stream closed because of', reason));
// "open" event is emitted on first .open() call and each time a new open is attempted
stream.on('open', () => console.log('Stream open...'));
// "ping" event is emitted each time a ping is received from the source stream
stream.on('ping', () => console.log('Received ping'));
```

When enabled, the auto retry behaviour will follow an infinite exponential backoff pattern.
You can change the default timings and max number of retries like this:

```js
stream.open({
  autoRetry: true,
  // Factor used to compute exponential backoff delays, defaults to 1.25
  backoffFactor: 1.5,
  // First iteration timeout in ms, also used to compute exponential backoff delays, defaults to 1500
  initRetryTimeout: 2000,
  // Maximum number of consecutive iterations the auto retry behaviour can do, defaults to Infinity
  maxRetryCount: 6,
});
```

## Logs stream (v4)

```js
import { ApplicationLogStream } from '@clevercloud/client/esm/streams/application-log.js';

// Load and cache config and tokens
const API_HOST = 'https://api.clever-cloud.com';
const tokens = {
  OAUTH_CONSUMER_KEY: 'your OAUTH_CONSUMER_KEY',
  OAUTH_CONSUMER_SECRET: 'your OAUTH_CONSUMER_SECRET',
  API_OAUTH_TOKEN: 'your API_OAUTH_TOKEN',
  API_OAUTH_TOKEN_SECRET: 'your API_OAUTH_TOKEN_SECRET',
};

// Create an EventsStream instance (appId is optional)
const logsStream = new ApplicationLogStream({
  apiHost: API_HOST,
  tokens,
  ownerId: 'YYY',
  appId: 'XXX',
  // optionnal auto retry config
  // retryConfiguration: {
  //   enabled: true,
    // backoffFactor: number,
    // initRetryTimeout: number,
    // maxRetryCount: number,
  // },
  // optionnal logs request params
  // since: Date,
  // until: Date,
  // service: string[],
  // limit: number,
  // deploymentId: string,
  // instanceId: string[],
  // filter: string,
  // field: string[],
  // throttleElements: number,
  // throttlePerInMilliseconds: number,
});

logsStream
  .on('open', (event) => console.debug('stream opened!', event))
  .on('error', (event) => console.error('error', event.error))
  .onLog((event) => console.log(event.data.date, event.data.message));

logsStream.start();

// You can also pause the stream
logsStream.pause();

// And resume it
logsStream.resume();
```

## License

This project is licensed under the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html).
